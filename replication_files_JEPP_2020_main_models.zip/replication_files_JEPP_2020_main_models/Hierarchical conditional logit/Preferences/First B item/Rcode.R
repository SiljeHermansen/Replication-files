setwd("C:/Users/ssherman/Dropbox/Rapporteurs - ECJ/RR - 2019")
library(rjags); library(dplyr)


#load("Hierarchical conditional logit/CJEU_choiceset.rda")
adr<-paste("Hierarchical conditional logit/Preferences/First B item/")

preferences <- c( "Current government - weighted", 
                  "Current government", 
                  "Appointing government")
j=1

for(j in 1 : length(preferences)){
  
  load("Data/CJEU_choiceset.rda")
  
  #remove cases
  df <- df[df$YearLodged < 2016 & df$YearLodged>=1980,] 
  df <- df[!is.na(df$First_time_b_item_before_court), ]
  df <- df[!is.na(df$Rapporteur.cum), ]

  
  #Remove appeals cases after the 2012 revisions of the RoP
  id <- which(grepl("P", df$cases_full) & df$DateAssigned > "2012-12-01")
  if(length(id) > 0){
    celex <- unique(df$celex[id])
    df <- df[!(df$celex %in% celex), ]
  }
  

  df$President[is.na(df$President)]=0
  
  df$Leadership <- ifelse(df$VicePresident == 1 | df$ChamberPresident == 1 | df$President ==1, 
                          1, 0)
  df$MembershipUnclear <- ifelse(df$ExitDecisionMade == 1 |
                                df$EntryDecisionNotMade == 1,
                              1, 0)
  
  
  #Remove president and all cases where he is rapporteur
  celex <- unique(df$celex[df$Rapporteur == 1 & df$President ==1])
  df <- df[!(df$celex %in% celex), ]
  df<- df[df$President!=1,]
  
  df$Subject_matter.cum[is.na(df$Subject_matter.cum)] = 0
  
  if(preferences[j] == "Current government"){
    df$Preferences <- df$FreeEconomy_cur
    df$Preferences.median <- df$FreeEconomy.median
    df <- df[!is.na(df$Preferences.median),]
    
    df$Preferences.cabinet <- df$left_right_cur
    
  }
  if(preferences[j] == "Current government - weighted"){
    df$Preferences <- df$FreeEconomy_cur.w
    df$Preferences.median <- df$FreeEconomy.w.median
    df <- df[!is.na(df$Preferences.median),]
    
    df$Preferences.cabinet <- df$left_right.w_cur
  }
  if(preferences[j] == "Appointing government"){
    df$Preferences <- df$FreeEconomy_app
    df$Preferences.median <- df$FreeEconomy_app.median
    df <- df[!is.na(df$Preferences.median),]
    
    df$Preferences.cabinet <- df$left_right_app
  }
  
  
  df$Preferences[is.na(df$Preferences)]=NA
  df$Preferences.cabinet[is.na(df$Preferences.cabinet)]=NA
  
  #Remove choice set without rapporteur
  df<-df[df$Allocation==1,]
  
  df<-df[order(df$choiceset),]
  start<-which(!duplicated(df$choiceset))
  stop<-which(!duplicated(df$choiceset, fromLast = T))
  startstop<-cbind(start, stop)
  
  y=df$Rapporteur
  x1=df[, c("Preferences",
            "Preferences.median",
            "AffectedCases.cum",
            "Subject_matter.cum",
            "CaseFromMS",
            "Rapporteur.cum",
            "MembershipUnclear",
            "Participation",
            "Leadership")]
  
  #Cross-level variables
  x2 <- df[!duplicated(df$celex), c("First_time_b_item_before_court")]
  
  
  
  if(preferences[j] == "Current government"|preferences[j] == "Current government - weighted"){
    #Party family
    df$family_name_pm_cur <- as.character(df$family_name_pm_cur)
    df$family_name_pm_cur[is.na(df$family_name_pm_cur)]="no family"
    df$family_name_pm_cur <- relevel(as.factor(df$family_name_pm_cur), 
                                     ref = "Conservative")
    
    
    x21 <- lme4::dummy(df$family_name_pm_cur)
    x21 <- cbind(df$Preferences.cabinet, x21)

    x21.m <- mean(x21[,1], na.rm = TRUE)
    x21.sd <- sd(x21[, 1], na.rm = TRUE)

  }
  
  if(preferences[j] == "Appointing government"){
    #Appoinint party family
    df$family_name_pm_app <- as.character(df$family_name_pm_app)
    df$family_name_pm_app[is.na(df$family_name_pm_app)]="no family"
    df$family_name_pm_app <- relevel(as.factor(df$family_name_pm_app), 
                                     ref = "Conservative")
    x21 <- lme4::dummy(df$family_name_pm_app)
    x21 <- cbind(df$Preferences.cabinet, x21)

    x21.m <- mean(x21[,1], na.rm = TRUE)
    x21.sd <- sd(x21[, 1], na.rm = TRUE)
  }
  
  
  #Number of regression coefficients
  
  N.beta=ncol(x1)-1+1#ncol(x2)
  
  N.gamma=ncol(x21)+1
  
  #Individual intercepts
  id<-unique(df$ID)
  id2<-match(df$ID, id)
  ID=id2
  
  N.id=length(unique(ID))
  
  #Data
  
  data <- list(N.beta=N.beta,
               m=nrow(startstop),
               x1 = x1,
               # cutpoint = 0.5,
               x2 = x2,
               x21 = x21,
               x21.m = x21.m,
               x21.sd = x21.sd,
               N.gamma=N.gamma,
               start=startstop[,1],
               end=startstop[,2],
               y=y)
  
  # model for report-allocation decisions
  
  #set up model
  cat("model{
    for (j in 1:m){
    for (i in start[j]:end[j]){		  
    y[i] ~ dbern(pi[i])
    pi[i] <- emu[i]/sum(emu[start[j]:end[j]])
    emu[i] <- exp(Xbeta[i])
    Xbeta[i] <- #a.id[ID[i]]+
    beta[1] * preferences[i]+
    beta[2] * preferences[i] * x2[j]+
    beta[3] * log(x1[i,3]+1)+    
    beta[4] * log(x1[i,4]+1)+    
    beta[5] * x1[i,5]+
    beta[6] * log(x1[i,6]+1)+
    beta[7] * x1[i,7]+
    beta[8] * (x1[i,8] - mean(x1[,8]))+
    beta[9] * x1[i,9]
    
    
    ##Impute appointing government preferences
          
      preferences[i] <- log(abs(x1[i,1] - x1[i,2])+1)
      
      x1[i,1] ~ dnorm(mu.pref1[i], tau.pref1)
      mu.pref1[i] <- gamma1[1]+
        gamma1[2]*x21[i,1]+
        gamma1[3]*x21[i,2]+
        gamma1[4]*x21[i,3]+
        gamma1[5]*x21[i,4]+
        gamma1[6]*x21[i,5]+
        gamma1[7]*x21[i,6]+
        gamma1[8]*x21[i,7]
      

      x21[i,1] ~ dnorm(x21.m, 1/(x21.sd * x21.sd))

      # for(k in 1:3){
      #   x21[i,k] ~ dnorm(x21.m[k], 1/(x21.sd[k] * x21.sd[k]))    
      # }
      }
      }


    ## Priors for regression coefficients
    for (i in 1:N.beta){
    beta[i] ~ dnorm(0,0.1)
    }
    
    for(i in 1:N.gamma){
    gamma1[i] ~ dnorm(0,0.1)
    }
    
    tau.pref1<-pow(sigma.pref1, -2)
    sigma.pref1~dunif(0,100)
    
    
    ###Priors for individual intercepts
    # #Map onto individual effects:
    # id.mean <- mean(a.id[])
    # 
    # for(j in 1:N.id){
    #   a.id[j]~dnorm(mu.id, tau.id) #random intercept
    #   id[j] <- a.id[j] - id.mean #Identified individual effect
    # }
    # mu.id~dnorm(0, 0.1)
    # tau.id<-pow(sigma.id, -2)
    # sigma.id~dunif(0,100)
}    
    
    ",
      file=paste(adr, "/", preferences[j], "/",  "Model.jag", sep=""))

  
  #Set up initials
  
  # load(paste(adr, "/", preferences[j], "/",  "model.rda", sep = ""))
  # inits <- model$state()
# 
  # inits <- list(list(beta = model$state()[[1]]$beta,
  #                    gamma1 = model$state()[[1]]$gamma1),
  #               list(beta = model$state()[[2]]$beta,
  #                    gamma1 = model$state()[[2]]$gamma1)
  #               )
#
#
  inits<-list(beta = rnorm(0, N.beta),
              gamma1 = rnorm(0,N.gamma))

  
  #Initialize model
  start.time <- Sys.time()
  model <- jags.model( file = paste(adr, "/", preferences[j], "/",  "Model.jag", sep=""),
                       data = data,
                       n.chains = 2,
                       inits = inits,
                       n.adapt = 200
  )
  end.time <- Sys.time()
  end.time-start.time
  
  
  results<-coda.samples(model=model,
                        variable.names = c("beta", "gamma1", # "id",
                                           "pi", "mu.pref1"),
                        n.iter = 10)

  # plot(results[,grep("beta.2", colnames(results[[1]]))])
  # plot(results[,grep("gamma1.2", colnames(results[[1]]))])
  summary(results[,grep("beta|gamma", colnames(results[[1]]))])

  
  save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
  save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
  save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))


  results<-coda.samples(model=model,
                        variable.names = c("beta", "gamma1", #"id",
                                           "pi", "mu.pref1"),
                        by = 10,
                        n.iter = 100)

  save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
  save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
  save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))

  results<-coda.samples(model=model,
                        variable.names = c("beta", "gamma1",#"id",
                                           "pi", "mu.pref1"),
                        thin=10,  by = 50,
                        n.iter = 890)

  save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
  save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
  save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))

  results<-coda.samples(model=model,
                        variable.names = c("beta", "gamma1", #"id",
                                           "pi"),
                        thin=10, by = 50,
                        n.iter = 1000)

  save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
  save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
  save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))

  results<-coda.samples(model=model,
                        variable.names = c("beta", "gamma1", #"id",
                                           "pi", "mu.pref1"),
                        thin=10, by = 100,
                        n.iter = 5000)

  save(results, file=paste(adr, "/", preferences[j], "/", "results.rda", sep=""))
  save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
  save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
}
 
# load(paste(adr, "/", preferences[j], "/",  "model.rda",sep=""))
# model$recompile()
# #adapt(model, n.iter = 200)
results<-coda.samples(model=model,
                      variable.names = c("beta", "gamma1", #"id",
                                         "pi", "mu.pref1"),
                      thin=10, by = 100,
                      n.iter = 1000)

# 
# summary(results[,grep("beta", colnames(results[[1]]))])
# plot(results[,grep("beta.1]|beta.2", colnames(results[[1]]))])
# 
