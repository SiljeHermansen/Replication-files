setwd("C:/Users/ssherman/Dropbox/Rapporteurs - ECJ/RR - 2019")
library(rjags);library(dplyr)


#load("Hierarchical conditional logit/CJEU_choiceset.rda")
adr1<-paste("Hierarchical conditional logit/Preferences/Preferences - agreement/")

observations <- c("Both", "Carrubba and Hankla", "Larsson and Naurin")
preferences <- c("Current government - weighted", "Current government", "Appointing government")

i = 1
j = 1

for(i in 1 : length(observations)){
  for(j in 1 : length(preferences)){
    
    load("Data/CJEU_choiceset.rda")
    
    
    df <- df[df$Prelim==1, ] # only preliminary cases
    
    
    
    #remove NA for the moment
    df$President[is.na(df$President)]=0
    
    df$Leadership <- ifelse(df$VicePresident == 1 | df$ChamberPresident == 1 | df$President ==1, 
                            1, 0)
    
    df$MembershipUnclear <- ifelse(df$ExitDecisionMade == 1 |
                                  df$EntryDecisionNotMade == 1,
                                1, 0)
    
    
    #Remove president and all cases where he is rapporteur
    celex <- unique(df$celex[df$Rapporteur == 1 & df$President ==1])
    df <- df[!(df$celex %in% celex), ]
    df<- df[df$President!=1,]
    
    #Remove appeals cases after the 2012 revisions of the RoP
    id <- which(grepl("P", df$cases_full) & df$DateAssigned > "2012-12-01")
    if(length(id) > 0){
      celex <- unique(df$celex[id])
      df <- df[!(df$celex %in% celex), ]
    }
    df$Subject_matter.cum[is.na(df$Subject_matter.cum)] = 0
    
    
    #Remove choice set without rapporteur
    df<-df[df$Allocation==1,]
    
    if(observations[i] == "Carrubba and Hankla"){
      df <- df[df$CarrubbaHankla == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_CH
      df$disagreement[is.na(df$disagreement_MS_CH)] = 0
      # df <- df[!is.na(df$disagreement), ]
    }
    
    if(observations[i] == "Larsson and Naurin"){
      df <- df[df$LarssonNaurin == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_LN
    }
    
    if(observations[i] == "Both"){
      df <- df[df$CarrubbaHankla == 1|df$LarssonNaurin == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_CH
      df$disagreement[df$LarssonNaurin == 1] = df$disagreement_MS_LN[df$LarssonNaurin == 1]
      df$disagreement[is.na(df$disagreement)] = 0
      # df <- df[!is.na(df$disagreement),]
    }
    
    if(preferences[j] == "Current government"){
      df$Preferences <- df$FreeEconomy_cur
      df$Preferences.median <- df$FreeEconomy.median
      
      df$Preferences.cabinet <- df$left_right_cur
      
    }
    if(preferences[j] == "Current government - weighted"){
      df$Preferences <- df$FreeEconomy_cur.w
      df$Preferences.median <- df$FreeEconomy.w.median
      
      df$Preferences.cabinet <- df$left_right.w_cur      
    }
    if(preferences[j] == "Appointing government"){
      df$Preferences <- df$FreeEconomy_app
      df$Preferences.median <- df$FreeEconomy_app.median
      df <- df[!is.na(df$Preferences.median),]
      
      df$Preferences.cabinet <- df$left_right_app
    }
    
    
    #Only consider cases filed after 1980
    # df <- df[df$YearLodged >= 1980, ]
    df <- df[df$date_lodged >= "1980-01-01" & df$date_lodged <= "2009-01-01", ]
    df$Preferences[is.na(df$Preferences)] = NA 
    df$Preferences.median[is.na(df$Preferences.median)] = NA 
    
    # #Sample a small size dataset for trial run
    # df <- df[df$choiceset %in% sample(df$choiceset, 50),]
    
    df<-df[order(df$choiceset),]
    start<-which(!duplicated(df$choiceset))
    stop<-which(!duplicated(df$choiceset, fromLast = T))
    startstop<-cbind(start, stop)
    
    y=df$Rapporteur
    x1=df[, c("Preferences",
              "Preferences.median",
              "AffectedCases.cum",
              "Subject_matter.cum",
              "CaseFromMS",
              "Rapporteur.cum",
              "MembershipUnclear",
              "Participation",
              "Leadership")]
    
    #Cross-level variables
    x2 <- df[!duplicated(df$celex), c("disagreement")]
    
    
    if(preferences[j] == "Current government"|preferences[j] == "Current government - weighted"){
      #Appointing party family
      df$family_name_pm_cur <- as.character(df$family_name_pm_cur)
      df$family_name_pm_cur[is.na(df$family_name_pm_cur)]="no family"
      df$family_name_pm_cur <- relevel(as.factor(df$family_name_pm_cur), 
                                       ref = "Conservative")
      x21 <- lme4::dummy(df$family_name_pm_cur)
      
      
      df$Preferences.cabinet[is.na(df$Preferences.cabinet)]=NA

      x21 <- cbind(df$Preferences.cabinet, x21)
      
      # #party intercepts
      # id<-unique(df$family_name_pm_cur)
      # id2<-match(df$family_name_pm_cur, id)
      # Party=id2
      # 
      # N.party=length(unique(Party))
      # 
      # x21 <- df$cabinet_lr_cur

    }
    
    if(preferences[j] == "Appointing government"){
      #Appointing party family
      df$family_name_pm_app <- as.character(df$family_name_pm_app)
      df$family_name_pm_app[is.na(df$family_name_pm_app)]="no family"
      df$family_name_pm_app <- relevel(as.factor(df$family_name_pm_app), 
                                       ref = "Conservative")
      x21 <- lme4::dummy(df$family_name_pm_app)
      x21 <- cbind(df$Preferences.cabinet, x21)
      
      # #party intercepts
      # id<-unique(df$family_name_pm_app)
      # id2<-match(df$family_name_pm_app, id)
      # Party=id2
      # 
      # N.party=length(unique(Party))
      # 
      # x21 <- df$cabinet_lr_app
      
    }
    
    x21.m <- mean(x21[,1], na.rm = TRUE)
    x21.sd <- sd(x21[, 1], na.rm = TRUE)
    
    
    #Number of regression coefficients
    
    if(observations[i] == "Carrubba and Hankla"){
      N.beta=ncol(x1)-2+1#ncol(x2)
    }
    if(observations[i] != "Carrubba and Hankla"){
      N.beta=ncol(x1)-1+1#ncol(x2)
    }
    
    N.gamma = ncol(x21)+1
    
    #Data
    data <- list(N.beta=N.beta,
                 m=nrow(startstop),
                 x1 = x1,
                 # cutpoint = 0.5,
                 x2 = x2,
                 x21 = x21,
                 N.gamma=N.gamma,
                 start=startstop[,1],
                 end=startstop[,2],
                 y=y,
                 x21.m = x21.m,
                 x21.sd = x21.sd)
    
    # model for report-allocation decisions
    if(observations[i] == "Carrubba and Hankla"){
      #set up model
      cat("model{
          for (j in 1:m){
          for (i in start[j]:end[j]){		  
          y[i] ~ dbern(pi[i])
          pi[i] <- emu[i]/sum(emu[start[j]:end[j]])
          emu[i] <- exp(Xbeta[i])
          Xbeta[i] <- #a.id[ID[i]]+
          beta[1] * preferences[i]+
          beta[2] * preferences[i] * x2[j]+
          beta[3] * log(x1[i,3]+1)+    
          beta[4] * log(x1[i,4]+1)+    
          beta[5] * x1[i,5]+
          beta[6] * log(x1[i,6]+1)+
          beta[7] * x1[i,7]+
          beta[8] * (x1[i,8] - mean(x1[,8]))
          
          
          ##Impute appointing government preferences
          preferences[i] <- log(abs(x1[i,1] - x1[i,2])+1)
          
          x1[i,1] ~ dnorm(mu.pref1[i], tau.pref1)
          mu.pref1[i] <- gamma1[1]+
          gamma1[2]*x21[i,1]+
          gamma1[3]*x21[i,2]+
          gamma1[4]*x21[i,3]+
          gamma1[5]*x21[i,4]+
          gamma1[6]*x21[i,5]+
          gamma1[7]*x21[i,6]
        
          x21[i,1] ~ dnorm(x21.m, 1/(x21.sd * x21.sd)) 
          }
          
          
          }
          
          ## Priors for regression coefficients
          for (i in 1:N.beta){
          beta[i] ~ dnorm(0,0.1)
          }
          
          for(i in 1:N.gamma){
          gamma1[i] ~ dnorm(0,0.1)
          }
          
          tau.pref1<-pow(sigma.pref1, -2)
          sigma.pref1~dunif(0,100)
          
    }",
          file=paste(adr, "/", preferences[j], "/", "Model.jag", sep=""))
}
    if(observations[i] != "Carrubba and Hankla"){
      #set up model
      cat("model{
          for (j in 1:m){
          for (i in start[j]:end[j]){		  
          y[i] ~ dbern(pi[i])
          pi[i] <- emu[i]/sum(emu[start[j]:end[j]])
          emu[i] <- exp(Xbeta[i])
          Xbeta[i] <- #a.id[ID[i]]+
          beta[1] * preferences[i]+
          beta[2] * preferences[i] * x2[j]+
          beta[3] * log(x1[i,3]+1)+    
          beta[4] * log(x1[i,4]+1)+    
          beta[5] * x1[i,5]+
          beta[6] * log(x1[i,6]+1)+
          beta[7] * x1[i,7]+
          beta[8] * (x1[i,8] - mean(x1[,8]))+
          beta[9] * x1[i,9]
          
          
          ##Impute appointing government preferences
          
          preferences[i] <- log(abs(x1[i,1] - x1[i,2])+1)
          
          x1[i,1] ~ dnorm(mu.pref1[i], tau.pref1)
          mu.pref1[i] <- gamma1[1]+
          gamma1[2]*x21[i,1]+
          gamma1[3]*x21[i,2]+
          gamma1[4]*x21[i,3]+
          gamma1[5]*x21[i,4]+
          gamma1[6]*x21[i,5]+
          gamma1[7]*x21[i,6]#+
#          gamma1[8]*x21[i,7]
          
          x21[i,1] ~ dnorm(x21.m, 1/(x21.sd * x21.sd))   
          }
          }
          
          ## Priors for regression coefficients
          for (i in 1:N.beta){
          beta[i] ~ dnorm(0,0.1)
          }
          
          for(i in 1:N.gamma){
          gamma1[i] ~ dnorm(0,0.1)
          }
          
          tau.pref1<-pow(sigma.pref1, -2)
          sigma.pref1~dunif(0,100)
          
          
          # # ###Priors for individual intercepts
          # #Map onto individual effects:
          # party.mean <- mean(a.party[])
          # 
          # for(j in 1:N.party){
          # a.party[j]~dnorm(mu.party, tau.party) #random intercept
          # party[j] <- a.party[j] - party.mean #Identified individual effect
          # }
          # mu.party~dnorm(0, 0.1)
          # tau.party<-pow(sigma.party, -2)
          # sigma.party~dunif(0,100)
          # 
          }",
          file=paste(adr, "/", preferences[j], "/", "Model.jag", sep=""))
      }
    
    #Set up initials
    load(paste(adr, "/", preferences[j], "/", "model.rda",sep=""))
    # inits <- model$state()
    
    inits <- list(list(beta = model$state()[[1]]$beta,
                       gamma1 = model$state()[[1]]$gamma1),
                  list(beta = model$state()[[2]]$beta,
                       gamma1 = model$state()[[2]]$gamma1)
    )

    # inits<-list(beta = rnorm(0, N.beta),
    #             gamma1 = rnorm(0, N.gamma))
    
    start.time <- Sys.time()
    #Initialize model
    model <- jags.model( file = paste(adr, "/", preferences[j], "/", "Model.jag", sep=""),
                         data = data,
                         n.chains = 2,
                         inits = inits,
                         n.adapt = 200
    )
    end.time <- Sys.time()
    end.time-start.time
    
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "gamma1",
                                             "pi"), 
                          n.iter = 10)
    
    # plot(results[,grep("beta.2", colnames(results[[1]]))])
    # plot(results[,grep("gamma1.2", colnames(results[[1]]))])
    summary(results[,grep("beta|gamma", colnames(results[[1]]))])
    
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", "gamma1", 
                                             "pi"), 
                          thin=10, by = 10,
                          n.iter = 100)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", "gamma1", 
                                             "pi","preferences"), 
                          thin=10, 
                          n.iter = 890)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    # tab<-summary(results)[[2]]
    # tab<-tab[grep("beta|gamma", rownames(tab)),]
    # tab
    
    # plot(results[,grep("beta.1|beta.2", colnames(results[[1]]))])
    # plot(results[,grep("a.i", colnames(results[[1]]))])
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", "gamma1", 
                                             "pi"), 
                          thin=10, by = 100,
                          n.iter = 1000)
    
    save(results, file=paste(adr, "/", preferences[j], "/", "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    # results<-coda.samples(model=model, 
    #                       variable.names = c("beta", "gamma1", 
    #                                          "pi"), 
    #                       thin=10, by = 100,
    #                       n.iter = 2000)
    # 
    # save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    # save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    # save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep="")) 
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", "gamma1", 
                                             "pi"), 
                          thin=50, by = 100,
                          n.iter = 5000)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    }
  }
# 
# load(paste(adr, "/", preferences[j], "/", "model.rda",sep=""))
# model$recompile()
# adapt(model, n.iter = 2)
# results<-coda.samples(model=model,
#                       variable.names = c("beta", "pi", "a.id"),
#                       n.iter = 10)
# summary(results[,grep("beta", colnames(results[[1]]))])
# plot(results[,grep("beta.1]|beta.2", colnames(results[[1]]))])
