setwd("C:/Users/ssherman/Dropbox/Rapporteurs - ECJ/Summer - 2019")
library(rjags);library(dplyr)


#load("Hierarchical conditional logit/CJEU_choiceset.rda")
adr1<-paste("Hierarchical conditional logit/Preferences/Preferences - agreement/")

observations <- c("Both", "Carrubba and Hankla", "Larsson and Naurin")
preferences <- c("Current government - weighted", "Current government", "Appointing government")

i = 2
j = 1

for(i in 1 : length(observations)){
  for(j in 1 : length(preferences)){
    
    #Load in data frame
    load("Data/CJEU_choiceset.rda")
    
    df <- df[df$Prelim==1, ] # only preliminary cases
    # df <- df[!is.na(df$nth_interpretation),]
    
    #remove NA for the moment
    df$President[is.na(df$President)]=0
    
    df$Leadership <- ifelse(df$VicePresident == 1 | df$ChamberPresident == 1 | df$President ==1, 
                            1, 0)
    
    df$MembershipUnclear <- ifelse(df$ExitDecisionMade == 1 |
                                  df$EntryDecisionNotMade == 1,
                                1, 0)
    
    
    #Remove president and all cases where he is rapporteur
    celex <- unique(df$celex[df$Rapporteur == 1 & df$President ==1])
    df <- df[!(df$celex %in% celex), ]
    df<- df[df$President!=1,]
    
    df$Subject_matter.cum[is.na(df$Subject_matter.cum)] = 0
    
    
    #Remove choice set without rapporteur
    df<-df[df$Allocation==1,]
    
    if(observations[i] == "Carrubba and Hankla"){
      df <- df[df$CarrubbaHankla == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_CH
      df$disagreement[is.na(df$disagreement_MS_CH)] = 0
      # df <- df[!is.na(df$disagreement), ]
    }
    
    if(observations[i] == "Larsson and Naurin"){
      df <- df[df$LarssonNaurin == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_LN
    }
    
    if(observations[i] == "Both"){
      df <- df[df$CarrubbaHankla == 1|df$LarssonNaurin == 1, ]
      adr <- paste(adr1, "/", observations[i], "/", sep = "")
      df$disagreement <- df$disagreement_MS_CH
      df$disagreement[df$LarssonNaurin == 1] = df$disagreement_MS_LN[df$LarssonNaurin == 1]
      df$disagreement[is.na(df$disagreement)] = 0
      # df <- df[!is.na(df$disagreement),]
      
      
    }
    
    if(preferences[j] == "Current government"){
      df$Preferences <- df$FreeEconomy_cur
      df$Preferences.median <- df$FreeEconomy.median
      
      #Load in imputed preferences
      load("Data/Current government/Preferences.rda")
      
    }
    if(preferences[j] == "Current government - weighted"){
      df$Preferences <- df$FreeEconomy_cur.w
      df$Preferences.median <- df$FreeEconomy.w.median
      
      #Load in imputed preferences
      load("Data/Current government - weighted/Preferences.rda")
      
    
    }
    if(preferences[j] == "Appointing government"){
      df$Preferences <- df$FreeEconomy_app
      df$Preferences.median <- df$FreeEconomy_app.median
      df <- df[!is.na(df$Preferences.median),]
      
      
      #Load in imputed preferences
      load("Data/Appointing government/Preferences.rda")
      
    }
    
    ##Add variable with imputed preferences
    id <- match(paste(df$ID, df$celex),
                paste(Preferences$ID, Preferences$celex))
    
    df$Preferences.imp.m = Preferences$pred.m[id]
    df$Preferences.imp.sd = Preferences$pred.sd[id]
    
    df$Preferences.imp.m[!is.na(df$Preferences)] = df$Preferences[!is.na(df$Preferences)]
    df$Preferences.imp.sd[!is.na(df$Preferences)] = 0.01
    rm(Preferences)
    
    #Only consider cases filed after 1980
    df <- df[df$YearLodged >= 1980, ]
    df$Preferences[is.na(df$Preferences)] = NA 
    df$Preferences.median[is.na(df$Preferences.median)] = NA 
    
    # #Sample a small size dataset for trial run
    # df <- df[df$choiceset %in% sample(df$choiceset, 50),]
    
    df<-df[order(df$choiceset),]
    start<-which(!duplicated(df$choiceset))
    stop<-which(!duplicated(df$choiceset, fromLast = T))
    startstop<-cbind(start, stop)
    
    y=df$Rapporteur
    x1=df[, c("Preferences",
              "Preferences.median",
              "AffectedCases.cum",
              "Subject_matter.cum",
              "CaseFromMS",
              "Rapporteur.cum",
              "MembershipUnclear",
              "Participation",
              "Leadership")]
    
    #Cross-level variables
    x2 <- df[!duplicated(df$celex), c("disagreement")]
    
    
    ##For imputations
    x21.m <- df$Preferences.imp.m
    x21.sd <- df$Preferences.imp.sd
    
    #Number of regression coefficients
    
    if(observations[i] == "Carrubba and Hankla"){
      N.beta=ncol(x1)-2+1#ncol(x2)
    }
    if(observations[i] != "Carrubba and Hankla"){
      N.beta=ncol(x1)-1+1#ncol(x2)
    }
    
    
    #Data
    data <- list(N.beta=N.beta,
                 m=nrow(startstop),
                 x1 = x1,
                 x2 = x2,
                 start=startstop[,1],
                 end=startstop[,2],
                 y=y,
                 x21.m = x21.m,
                 x21.sd = x21.sd)
    
    # model for report-allocation decisions
    if(observations[i] == "Carrubba and Hankla"){
      #set up model
      cat("model{
          for (j in 1:m){
          for (i in start[j]:end[j]){		  
          y[i] ~ dbern(pi[i])
          pi[i] <- emu[i]/sum(emu[start[j]:end[j]])
          emu[i] <- exp(Xbeta[i])
          Xbeta[i] <- #a.id[ID[i]]+
          beta[1] * preferences[i]+
          beta[2] * preferences[i] * x2[j]+
          beta[3] * log(x1[i,3]+1)+    
          beta[4] * log(x1[i,4]+1)+    
          beta[5] * x1[i,5]+
          beta[6] * log(x1[i,6]+1)+
          beta[7] * x1[i,7]+
          beta[8] * (x1[i,8] - mean(x1[,8]))
          
          
          ##Impute appointing government preferences
          preferences[i] <- log(abs(x1[i,1] - x1[i,2])+1)
          
          x1[i,1] ~ dnorm(x21.m[i], pow(x21.sd[i], -2))
          }
          
          
          }
          
          ## Priors for regression coefficients
          for (i in 1:N.beta){
          beta[i] ~ dnorm(0,0.1)
          }
          
    }",
          file=paste(adr, "/", preferences[j], "/", "Model.jag", sep=""))
}
    if(observations[i] != "Carrubba and Hankla"){
      #set up model
      cat("model{
          for (j in 1:m){
          for (i in start[j]:end[j]){		  
          y[i] ~ dbern(pi[i])
          pi[i] <- emu[i]/sum(emu[start[j]:end[j]])
          emu[i] <- exp(Xbeta[i])
          Xbeta[i] <- #a.id[ID[i]]+
          beta[1] * preferences[i]+
          beta[2] * preferences[i] * x2[j]+
          beta[3] * log(x1[i,3]+1)+    
          beta[4] * log(x1[i,4]+1)+    
          beta[5] * x1[i,5]+
          beta[6] * log(x1[i,6]+1)+
          beta[7] * x1[i,7]+
          beta[8] * (x1[i,8] - mean(x1[,8]))+
          beta[9] * x1[i,9]
          
          
          ##Impute appointing government preferences
          
          preferences[i] <- log(abs(x1[i,1] - x1[i,2])+1)
          
          x1[i,1] ~ dnorm(x21.m[i], pow(x21.sd[i], -2))
          }
          }
          
          ## Priors for regression coefficients
          for (i in 1:N.beta){
          beta[i] ~ dnorm(0,0.1)
          }
          
          }",
          file=paste(adr, "/", preferences[j], "/", "Model.jag", sep=""))
      }
    
    #Set up initials
    load(paste(adr, "/", preferences[j], "/", "model.rda",sep=""))
    # inits <- model$state()
    
    inits <- list(list(beta = model$state()[[1]]$beta),
                  list(beta = model$state()[[2]]$beta)
    )

    # inits<-list(beta = rnorm(0, N.beta),
    #             gamma1 = rnorm(0, N.gamma))
    
    start.time <- Sys.time()
    #Initialize model
    model <- jags.model( file = paste(adr, "/", preferences[j], "/", "Model.jag", sep=""),
                         data = data,
                         n.chains = 2,
                         inits = inits,
                         n.adapt = 200
    )
    end.time <- Sys.time()
    end.time-start.time
    
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          n.iter = 10)
    
    plot(results[,grep("beta.2", colnames(results[[1]]))])
    summary(results[,grep("beta|gamma", colnames(results[[1]]))])
    
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          thin=10, by = 10,
                          n.iter = 100)

    plot(results[,grep("beta.2", colnames(results[[1]]))])
    summary(results[,grep("beta|gamma", colnames(results[[1]]))])
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          thin=10, 
                          n.iter = 890)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          thin=10, by = 100,
                          n.iter = 1000)
    
    
    plot(results[,grep("beta.2", colnames(results[[1]]))])
    summary(results[,grep("beta|gamma", colnames(results[[1]]))])
    
    save(results, file=paste(adr, "/", preferences[j], "/", "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          thin=10, by = 100,
                          n.iter = 2000)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep="")) 
    
    plot(results[,grep("beta.2", colnames(results[[1]]))])
    summary(results[,grep("beta", colnames(results[[1]]))])
    
    results<-coda.samples(model=model, 
                          variable.names = c("beta", 
                                             "pi"), 
                          thin=50, by = 100,
                          n.iter = 5000)
    
    save(results, file=paste(adr, "/", preferences[j], "/",  "results.rda", sep=""))
    save(model, file=paste(adr, "/", preferences[j], "/",  "model.rda", sep=""))
    save(data, file=paste(adr, "/", preferences[j], "/",  "jagsdata.rda", sep=""))
    
    }
  }
# 
# load(paste(adr, "/", preferences[j], "/", "model.rda",sep=""))
# model$recompile()
# adapt(model, n.iter = 2)
# results<-coda.samples(model=model,
#                       variable.names = c("beta", "pi", "a.id"),
#                       n.iter = 10)
# summary(results[,grep("beta", colnames(results[[1]]))])
# plot(results[,grep("beta.1]|beta.2", colnames(results[[1]]))])
