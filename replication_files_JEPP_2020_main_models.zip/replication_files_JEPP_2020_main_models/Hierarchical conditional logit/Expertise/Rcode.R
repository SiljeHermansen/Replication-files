setwd("C:/Users/ssherman/Dropbox/Rapporteurs - ECJ/Summer - 2019")
library(rjags)


adr<-paste("Hierarchical conditional logit/Expertise/")


Expertise <- c("Affected cases", "EurLex", "Commission", "Council")
i=2
for(i in 1:length(Expertise)){
  
  load("Data/CJEU_choiceset.rda")
  #remove cases after2015
  df<-df[df$YearLodged<2016 & df$YearLodged>=1980,]
  df$AffectedCases.cum[is.na(df$AffectedCases.cum)] = 0
  df$Subject_matter.cum[is.na(df$Subject_matter.cum)] = 0
  
  if(Expertise[i] == "Affected cases"){
    df<- df[!is.na(df$AffectedCases.cum),]
    df$Expertise = df$AffectedCases.cum
  }
  
  
  if(Expertise[i] == "EurLex"){
    df<- df[!is.na(df$Subject_matter.cum),]
    df$Expertise = df$Subject_matter.cum
  }
  
  if(Expertise[i] == "Commission"){
#    df<-df[df$Prelim==1,]
    df <- df[!is.na(df$Subject_Commission.cum),]
    df$Expertise = df$Subject_Commission.cum
  }
  
  if(Expertise[i] == "Council"){
#    df<-df[df$Prelim==1,]
    df <- df[!is.na(df$Subject_Council.cum),]
    df$Expertise = df$Subject_Council.cum
  }
  
  
  df$President[is.na(df$President)]=0
  df$Leadership <- ifelse(df$VicePresident == 1| df$ChamberPresident == 1, 1, 0)
  df$MembershipUnclear <- ifelse(df$ExitDecisionMade == 1 |
                                   df$EntryDecisionNotMade == 1,
                                 1, 0)
  
  
  #Remove choice set with out rapporteur
  df<-df[df$Allocation==1,]
  
  #Remove president and all cases where he is rapporteur
  celex <- unique(df$celex[df$Rapporteur == 1 & df$President ==1])
  df <- df[!(df$celex %in% celex), ]
  df<- df[df$President!=1,]
  
  ##Sample a small size data set for trial run
  # df <- df[df$choiceset %in% sample(df$choiceset, 200),]
  
  
  df<-df[order(df$choiceset),]
  start<-which(!duplicated(df$choiceset))
  stop<-which(!duplicated(df$choiceset,fromLast=T))
  startstop<-cbind(start,stop)
  
  y=df$Rapporteur
  
  x1=df[,c("Expertise",
           "CaseFromMS",
           "Rapporteur.cum",
           "MembershipUnclear",
           "Participation",
           "Leadership")]
  
  
  #Numberof regression coefficients
  N.beta=ncol(x1)
  
  ##For NA imputations
  
  #Individualintercepts
  id<-unique(df$ID)
  id2<-match(df$ID,id)
  ID=id2
  
  
  N.id=length(unique(ID))
  
  #Data
  
  data<-list(N.beta=N.beta,
             m=nrow(startstop),
             x1=x1,
             start=startstop[,1],
             end=startstop[,2],
             y=y,
             ID=ID,
             N.id=N.id
             
  )
  
  
  #model for report-allocation decisions
  
  #set up model
  cat("model{
      for(j in 1:m){
      for(i in start[j]:end[j]){		
      y[i]~dbern(pi[i])
      emu[i]<-exp(mu[i])
      pi[i]<-emu[i]/sum(emu[start[j]:end[j]])
      mu[i]<-Xbeta[i]
      
      Xbeta[i]<-#a.id[ID[i]]+
        beta[1]*log(x1[i,1]+1)+
        beta[2]*x1[i,2]+
        beta[3]*log(x1[i,3]+1)+
        beta[4]*x1[i,4]+
        beta[5]*(x1[i,5]-mean(x1[,5]))+
        beta[6]*x1[i,6]
      }
      
      }
      
      ##Priors for regression coefficients
      
      for(i in 1:N.beta){
      beta[i]~dnorm(0,0.1)
      }
      
      # ###Priors for individual intercepts
      # id.mean <- mean(a.id[])
      # 
      # for(j in 1:N.id){
      # a.id[j]~dnorm(mu.id, tau.id) #random intercept
      # id[j] <- a.id[j] - id.mean #Identified individual effect
      # }
      # 
      # mu.id~dnorm(0, 0.1)
      # tau.id<-pow(sigma.id,-2)
      # sigma.id~dunif(0,100)
      
      }
      
      ",
      
      file=paste(adr,  "Model.jag", sep=""))
  
  
  #Set up initials
  
  load(paste(adr, "/", Expertise[i], "/",  "model.rda", sep = ""))
  inits <- list(list(beta = model$state()[[1]]$beta),
                list(beta = model$state()[[2]]$beta)
  )
  
  # inits<-list(beta = rnorm(0, N.beta),
  #             a.id = rep(0, N.id))
  
  start.time <- Sys.time()
  #Initialize model
  model <- jags.model( file = paste(adr, "Model.jag", sep=""),
                       data = data,
                       n.chains = 2,
                       inits = inits,
                       n.adapt = 200
  )
  end.time <- Sys.time()
  end.time-start.time
  
  
  results<-coda.samples(model=model, 
                        variable.names = c("beta", 
                                           "pi"), 
                        #                      thin=10, 
                        n.iter = 10)
  
  
  # plot(results[,grep("beta.1|beta.3", colnames(results[[1]]))])
  
  # summary(results[,grep("beta", colnames(results[[1]]))])
  
  save(results,file=paste(adr, Expertise[i], "/","results.rda",sep=""))
  save(model,file=paste(adr, Expertise[i], "/","model.rda",sep=""))
  save(data,file=paste(adr, Expertise[i], "/","jagsdata.rda",sep=""))  
  
  results<-coda.samples(model=model,
                        variable.names=c("beta",
                                         "pi"),
                        thin=1,
                        by = 10,
                        n.iter=100)
  
  
  save(results,file=paste(adr, Expertise[i], "/","results.rda",sep=""))
  save(model,file=paste(adr, Expertise[i], "/", "model.rda",sep=""))
  save(data,file=paste(adr, Expertise[i], "/", "jagsdata.rda",sep=""))  
  
  results<-coda.samples(model=model,
                        variable.names=c("beta", "a.id",
                                         "pi"),
                        thin=10, by = 50,
                        n.iter=890)
  
  save(results,file=paste(adr, "results.rda",sep=""))
  save(model,file=paste(adr, "model.rda",sep=""))
  save(data,file=paste(adr, "jagsdata.rda",sep=""))  
  
  results<-coda.samples(model=model,
                        variable.names=c("beta", 
                                         "pi"),
                        thin=10,
                        n.iter=1000)
  
  
  save(results,file=paste(adr, Expertise[i], "/","results.rda",sep=""))
  save(model,file=paste(adr, Expertise[i], "/", "model.rda",sep=""))
  save(data,file=paste(adr, Expertise[i], "/", "jagsdata.rda",sep=""))  
  
  results<-coda.samples(model=model,
                        variable.names=c("beta",
                                         "pi"),
                        thin=20,
                        n.iter=2000)
  
  
  save(results,file=paste(adr, Expertise[i], "/", "results.rda",sep=""))
  save(model,file=paste(adr, Expertise[i], "/", "model.rda",sep=""))
  save(data,file=paste(adr, Expertise[i], "/", "jagsdata.rda",sep=""))  
  
  # results<-coda.samples(model=model,
  #                       variable.names=c("beta",
  #                                        "pi"),
  #                       thin=10,
  #                       n.iter=5000)
  # 
  # 
  # save(results,file=paste(adr, Expertise[i], "/", "results.rda",sep=""))
  # save(model,file=paste(adr, Expertise[i], "/", "model.rda",sep=""))
  # save(data,file=paste(adr, Expertise[i], "/", "jagsdata.rda",sep="")) 
}

# 
# load(paste(adr, Expertise[i], "/", "model.rda",sep=""))
# model$recompile()
# adapt(model, n.iter = 2)
# results<-coda.samples(model=model,
#                       variable.names = c("beta", "pi"),
#                       n.iter = 2000, thin = 20, by = 50)
# summary(results[,grep("beta", colnames(results[[1]]))])
# plot(results[,grep("beta.1]|beta.2", colnames(results[[1]]))])
