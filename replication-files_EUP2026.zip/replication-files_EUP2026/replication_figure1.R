install.packages("ggplot2")
library(ggplot2)

#read in data
supply<-read.csv("~/Dropbox/ECJ Review Piece/eup_supply_figure_data.csv", header=T)


####Makes the Court of Justice panel of the figure
ggplot(supply, aes(x = year)) +
  geom_line(aes(y = total_ecj), color = "black", linetype = "solid", size = .5) +
  geom_line(aes(y = refs_ecj), color = "black", linetype = "dotted", size = .5) +
  geom_line(aes(y = direct_actions_ecj), color = "black", linetype = "dashed", size = .5) +
  scale_y_continuous(
    name = "Number of Cases"  ) +
  xlab("Year") +
  ggtitle("New Cases by Year at the Court of Justice") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),         # remove all grid lines
    axis.title.y.left = element_text(color = "black"),
    axis.title.y.right = element_text(color = "black"),
        plot.title = element_text(hjust = 0.5)  # center the title
  )+
  annotate("text", x = 2010, y = 750, label = "Total Cases", color = "black",size=3)+
  annotate("text", x = 2010, y = 20, label = "Direct Actions", color = "black",size=3)+
  annotate("text", x = 2018, y = 350, label = "Preliminary\nReferences", color = "black",size=3)

#Makes the General Court panel of the figure

ggplot(supply, aes(x = year)) +
  geom_line(aes(y = total_gc), color = "black", linetype = "solid", size = .5) +
  geom_line(aes(y = annulment_gc), color = "black", linetype = "dashed", size = .5) +
  scale_y_continuous(
    name = "Number of Cases" ) +
    scale_x_continuous(
    name="Year",
    limits=c(1989,NA)) +
  ggtitle("New Cases by Year at the General Court") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),         # remove all grid lines
    axis.title.y.left = element_text(color = "black"),
    axis.title.y.right = element_text(color = "black"),
        plot.title = element_text(hjust = 0.5)  # center the title
  )+
  annotate("text", x = 2008, y = 770, label = "Total Cases", color = "black",size=3)+
  annotate("text", x = 2018, y = 250, label = "Annulment Actions", color = "black",size=3)

#Makes the General Court panel of the figure