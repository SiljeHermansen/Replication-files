library(ggeffects)
library(ggplot2)
library(scales)  # for rescale()

infringements<- read.csv("~/Dropbox/ECJ Review Piece/Replication Files/Krehbiel_replication_data_EUP_essay.csv",header=T)

q67 <- quantile(infringements $pm_eu_position, probs = 0.67, na.rm = TRUE)


infringements$pm_eu_dich <- ifelse(infringements $pm_eu_position>q67,1,0)

ecj1 <- lm(duration_days ~ decision_election_diff* pm_eu_dich  , data =subset( infringements, is_successful==1))
summary(ecj1)

dens <- density(na.omit(infringements $decision_election_diff), from = 0)
dens_df <- data.frame(
  x = dens$x,
  y = rescale(dens$y, to = c(300, 350))  # adjust to match y-axis range
)

# 2. Get ggpredict output
pred_plot <- ggpredict(ecj1, terms = c("decision_election_diff", "pm_eu_dich"))

# 3. Build plot
ggplot() +
  # Background density plot
  geom_area(data = dens_df, aes(x = x, y = y), fill = "gray20", alpha = 0.5) +

  # Confidence bands
  geom_ribbon(data = pred_plot, aes(x = x, ymin = conf.low, ymax = conf.high, group = group),
              fill = "gray80", alpha = 0.4) +

  # Prediction lines
  geom_line(data = pred_plot, aes(x = x, y = predicted, linetype = group), color = "black", size = 1) +

  # Labels
  labs(
    title = "Electoral Cycle and Proceeding Duration\nBy Nat'l Gov't Support for the EU",
    x = "Days Between Last Election and Court of Justice Decision",
    y = "Case Duration (Days)",
    linetype = ""
  ) +

  # Line types and labels
  scale_linetype_manual(
    values = c("solid", "dotted"),
    labels = c("Low to Medium Nat'l Gov't Support for EU", "High Nat'l Gov't Support for EU")
  ) +

  # Coordinate limits
  coord_cartesian(xlim = c(0, 1845), ylim = c(300, 650)) +
scale_x_continuous(expand = expansion(mult = c(0, 0.05))) +  # no left padding
  geom_vline(xintercept = 0, color = "black", size = 0.9) +    # y-axis line at x=0
#  geom_hline(yintercept = 494, color = "black", size = 0.9) +
  # Theme
  theme_minimal() +
  theme(
    panel.grid = element_blank(),
    plot.title = element_text(hjust = 0.5),
    axis.line = element_line(color = "black"),
    axis.ticks = element_line(color = "black"),
    legend.position = "bottom"
  )
  
#####################
#Supplemental Materials#
#####################
   
library(stargazer)


library(MASS)

ecj1_nb <- glm.nb(duration_days ~ decision_election_diff* pm_eu_dich  , data =subset( infringements, is_successful==1))
summary(ecj1_nb)

stargazer(ecj1, ecj1_nb, type="latex", star.cutoffs=c(0.05))